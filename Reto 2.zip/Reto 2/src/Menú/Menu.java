package Menú;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;

public class Menu {

    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner texto = new Scanner(System.in);
        int opc = 1;
        while (opc != 4) {
            System.out.println("             BIENVENIDO AL RETO 2\n");
            System.out.println("(1) Calcular el cuadrado de los primeros N números \n" + "(2) Primeros N números primos y su suma\n" + "(3) Desarrollo de bicicleta\n" + "(4) Salir\n");
            System.out.print("Escribe el número de la operación que deseas: ");
            opc = texto.nextInt();
            System.out.println("");
            switch (opc) {
                case 1:
                    //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                    Menu.punto1();
                    break;
                case 2:
                    Menu.punto2();
                    break;
                case 3:
                    Menu.punto3();
                    break;
                case 4:
                    System.exit(0);
            }
            System.out.println("");
            System.out.println("");
        }
    }

    public static void punto1() {
        int n = 0, contador = 1;
        Scanner dato = new Scanner(System.in);
        while (n == 0) {
            System.out.print("Por favor indica los primero N enteros (desde el 1) para encontrar los cuadrados: ");
            n = dato.nextInt();
            System.out.println("");
            if (n != 0) {
                int num = 0, impar, suma = 0;
                while (contador <= n) {
                    int start = 1;
                    impar = num * 2 + 1;
                    suma = suma + impar;
                    System.out.println(contador + "^2 = " + suma);
                    num++;
                    contador++;
                }
            } else {
                Menu.error();
            }
        }
    }

    public static void punto2() {
        int n = 0, suma = 0, num = 2;
        List<Integer> primos = new ArrayList<>();
        boolean esprimo;
        Scanner dato = new Scanner(System.in);
        while (n <= 1) {
            System.out.print("Escribe un número entero aleatorio (mayor a 1): ");
            n = dato.nextInt();
            System.out.println("");
            if (n > 1) {
                while (num <= n) {
                    esprimo = Menu.esPrimo(num);
                    if (esprimo == true) {
                        suma = suma + num;
                        primos.add(num);
                    }
                    num++;
                }
            } else {
                Menu.error();
            }
        }
        System.out.print("Los números primos son: ");
        for (int i = 0; i <= primos.size() - 1; i++) {
            System.out.print(primos.get(i) + " ");
        }
        System.out.println("");
        System.out.println("La suma de todos los números primos es: " + suma);
    }

    public static void punto3() {
        int plato1 = 0, plato2 = 0, contador = 1, piñon, i = 0, dimension = 0;
        double metraje1, metraje2, circunferencia = 0;;
        int[] piñones = new int[12];
        int[] desarrollo = new int[12];
        Scanner dato = new Scanner(System.in);
        while (plato1 < 16 || plato1 > 60) {
            System.out.println("El número de dientes de los platos delanteros son de mínimo 16 y máximo 60");
            System.out.print("Por favor indica el número de dientes del primer plato delantero (obligatorio): ");
            plato1 = dato.nextInt();
            System.out.println("");
            if (plato1 >= 16 && plato1 <= 60) {
                while (plato2 < 16 || plato2 > 60) {
                    System.out.print("Por favor indica el número de dientes del segundo plato delantero (opcional): ");
                    plato2 = dato.nextInt();
                    System.out.println("");
                    if (plato2 < 16 || plato2 > 60) {
                        Menu.error();
                    }
                }
            } else {
                Menu.error();
            }
        }
        System.out.println("A continuación indicarás el número de dientes de 12 piñones traseros (mínimo 9, máximo 60)");
        while (i < piñones.length) {
            System.out.print("Por favor indica la cantidad de dientes del piñón N° " + contador + ": ");
            piñon = dato.nextInt();
            System.out.println("");
            if (piñon >= 9 && piñon <= 60) {
                piñones[i] = piñon;
                i++;
                contador++;
            } else {
                Menu.error();
            }
        }
        System.out.print("Estas son las dimensiones de la llantas: \n" + "(1) 29x2.1\n" + "(2) 29x2.2\n" + "(3) 29x2.1\n");
        System.out.println("");
        while (dimension < 1 || dimension > 3) {
            System.out.print("Por favor selecciona una dimensión: ");
            dimension = dato.nextInt();
            System.out.println("");
            switch (dimension) {
                case 1:
                    circunferencia = 2.288;
                    break;
                case 2:
                    circunferencia = 2.298;
                    break;
                case 3:
                    circunferencia = 2.326;
                    break;
                default:
                    Menu.error();
            }
        }
        System.out.println("");
        System.out.println("El valor en metros para ambos platos (24 resultados en total): \n");

        for (int j = 0; j < piñones.length; j++) {
            metraje1 = circunferencia * plato1 / piñones[j];
            metraje2 = circunferencia * plato2 / piñones[j];

            System.out.println("Para " + piñones[j] + " piñones: " + metraje1 + " metros (Plato 1 de " + plato1 + " dientes)   y  " + metraje2 + " metros (Plato 2 de " + plato2 + " dientes)\n");
        }

    }

    public static void error() {
        System.out.println("Número erróneo. Inténtalo de nuevo.");
        System.out.println("");
        System.out.println("");
    }

    public static boolean esPrimo(int numero) {
//Sé que una manera más sencilla y eficiente era dividiendo el parámetro por 2, 3, 5, 7 y 11, pero simplemente quise practicar BigInteger
        int inicial = 2;
        BigInteger total = new BigInteger("1");
        BigInteger suma = new BigInteger("2");
        BigInteger modulo = new BigInteger("" + numero);
        boolean r = false;
        while (inicial <= numero - 1) {
            total = total.multiply(suma);
            suma = suma.add(new BigInteger("1"));
            inicial++;
        }
        total = total.add(new BigInteger("1"));
        modulo = total.mod(modulo);
        String x = modulo.toString();
        if (x == "0") {
            r = true;
        }
        return r;
    }
}
